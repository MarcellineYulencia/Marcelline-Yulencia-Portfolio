FARM GUARDIAN - WINDOWS 64-BIT

CONTROLS
Move: WASD, arrow keys, or the on-screen joystick.
Pick up / deliver an animal: E or the on-screen action button.
Catch a thief: hold F or hold Catch Thief while staying close.
Plant: hold P or hold Plant Seed near a planting plot.
Pause / resume: Esc or the pause controls.

LIFE AND SCORE
Life = animals that have not been permanently stolen.
Score = 100 per animal currently safe in its pen + 150 per planted plot.
Temporary theft removes that animal's score, not a life. Delivering it again
restores its score; it cannot generate unlimited points.
Score is separate from saved coins and resets on a new level/retry.

WIN / LOSE
Win: rescue all remaining animals and complete planting before time runs out.
Lose: all animals permanently stolen, or the timer expires.

PROGRESS
Coins, upgrades, stars and owned skins save locally for your Windows user.
Settings contains sound volume and Reset Progress (with confirmation).
